﻿using Microsoft.AspNetCore.Mvc;
using ApiExemplo.Models;

namespace ApiExemplo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PessoaController : ControllerBase
    {
       
        [HttpGet("imc")]
        public ActionResult<double> CalcularImc([FromQuery] string nome, [FromQuery] double peso, [FromQuery] double altura)
        {
            if (peso <= 0 || altura <= 0)
                return BadRequest("Peso e altura devem ser maiores que zero.");

            double imc = peso / (altura * altura);
            return Ok(Math.Round(imc, 2));
        }

      
        [HttpGet("imc-descricao")]
        public ActionResult<ImcInfo> DescricaoImc([FromQuery] double imc)
        {
            var info = new ImcInfo { Imc = imc, Descricao = DescricaoPorImc(imc) };
            return Ok(info);
        }

        private string DescricaoPorImc(double imc)
        {
            if (imc < 18.5) return "Abaixo do peso";
            if (imc < 25) return "Peso normal";
            if (imc < 30) return "Sobrepeso";
            if (imc < 35) return "Obesidade grau I";
            if (imc < 40) return "Obesidade grau II";
            return "Obesidade grau III";
        }
    }
}
